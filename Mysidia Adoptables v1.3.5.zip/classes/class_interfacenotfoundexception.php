<?php

class InterfaceNotFoundException extends Exception{

}
    
?>