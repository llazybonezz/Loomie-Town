<?php

class InvalidIDException extends Exception{

}
    
?>