<?php

class TradeInvalidException extends InvalidActionException{

}
?>