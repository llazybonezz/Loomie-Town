<?php

class ViewException extends Exception{

}
?>