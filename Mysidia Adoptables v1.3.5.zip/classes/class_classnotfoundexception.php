<?php

class ClassNotFoundException extends Exception{

}
    
?>