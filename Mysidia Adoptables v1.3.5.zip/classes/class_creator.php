<?php

interface Creator{
  // The creator interface for factory or abstract factory pattern used in Mysidia Adoptables  
  
  public function create();
  public function massproduce();
}
?>