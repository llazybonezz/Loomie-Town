<?php

class DuplicateIDException extends Exception{

}
    
?>