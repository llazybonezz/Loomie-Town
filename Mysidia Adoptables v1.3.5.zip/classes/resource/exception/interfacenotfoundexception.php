<?php

namespace Resource\Exception;
use Exception;

class InterfaceNotFoundException extends Exception{

}
    
?>