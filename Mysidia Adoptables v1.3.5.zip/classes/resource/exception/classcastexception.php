<?php

namespace Resource\Exception;
use Exception;

class ClassCastException extends Exception{

}
    
?>