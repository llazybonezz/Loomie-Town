<?php

namespace Resource\Exception;
use \Exception as Exception;

class IllegalArgumentException extends Exception{

}
    
?>