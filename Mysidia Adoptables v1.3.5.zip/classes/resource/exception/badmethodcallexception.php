<?php

class BadMethodCallException extends BadFunctionCallException{

}
    
?>