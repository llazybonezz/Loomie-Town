<?php

class BadFunctionCallException extends LogicException{

}
    
?>