<?php

namespace Resource\Exception;
use Exception;

class IllegalStateException extends Exception{

}
    
?>