<?php

interface Container{
  // The interface Container, must be implemented for contain type classes
  
  public function display();  
} 
?>