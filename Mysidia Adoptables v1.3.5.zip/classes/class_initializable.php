<?php

interface Initializable{
  // The Initializable interface for factory or abstract factory pattern used in Mysidia Adoptables  
  
  public function initialize();
}
?>