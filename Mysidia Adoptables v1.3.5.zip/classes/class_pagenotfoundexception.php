<?php

class PageNotFoundException extends Exception{

}
?>