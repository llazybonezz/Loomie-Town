<?php

class ItemException extends Exception{

}
    
?>