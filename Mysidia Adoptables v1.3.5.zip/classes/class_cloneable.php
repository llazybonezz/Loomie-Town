<?php

interface Cloneable{
  // The clonable interface, one of the four parent interfaces for objective interface.
  
  public function __clone();
}
?>