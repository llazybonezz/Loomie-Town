<?php

class RegisterException extends Exception{

}
    
?>