<?php

class DonationException extends Exception{

}
    
?>