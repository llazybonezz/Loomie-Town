<?php

class NoPermissionException extends Exception{

}
    
?>