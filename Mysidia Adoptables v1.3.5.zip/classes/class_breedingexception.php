<?php

class BreedingException extends Exception{
    
}
    
?>