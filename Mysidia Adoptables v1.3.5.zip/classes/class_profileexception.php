<?php

class ProfileException extends Exception{

}
    
?>