<?php

class InvalidActionException extends Exception{

}
    
?>