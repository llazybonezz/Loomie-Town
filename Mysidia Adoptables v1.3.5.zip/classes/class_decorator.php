<?php

interface Decorator{
  // The decorator interface for Decorator pattern used in Mysidia Adoptables

  public function decorate();
} 
?>